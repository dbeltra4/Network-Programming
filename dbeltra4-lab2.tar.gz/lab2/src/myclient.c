#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#define MAXLINE         4086 

// Data Structure for packet ordering, as per ed discussion
typedef struct Packet {
    int seq_number;
} Packet;

// One by one
// We need indexing, queueing, and linked lists
// Dont need indexing if you have two arrays

void DG_CLI(FILE *file, FILE *out, int s_fd, int mtu, const struct sockaddr *pservaddr, socklen_t servlen){
     // Timeout Constraint
     struct timeval t;
     t.tv_sec = 60;
     t.tv_usec = 0;
     if(setsockopt(s_fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof(t)) < 0){
        fprintf(stderr, "Error in setsockopt()\n");
        exit(EXIT_FAILURE);
     } 
     // Reading into the file
     fseek(file, 0L, SEEK_END);
     long f_size = ftell(file);
     rewind(file);

     // Calculates the number of packets
     int num_packets = (f_size + mtu - 1) / mtu;
     int seq_num = 0;     
     char buff[MAXLINE];
     size_t read_bite;

     // Array for to hold packet data
     Packet send_pack[num_packets];
     Packet recv_pack[num_packets];
     while(seq_num < num_packets){
           read_bite = fread(buff, 1, mtu, file);
    
           // Packet handling
           Packet p; 
           p.seq_number = seq_num;   
	   send_pack[seq_num] = p;

           // Client sendto()
           if(sendto(s_fd, &p, sizeof(Packet), 0, pservaddr, servlen) < 0){
	      fprintf(stderr, "Error in sendto() for client...\n");
	      exit(EXIT_FAILURE);
	   }

	   // Client recvfrom(), (e.g. ACK)
	   Packet ack; 
	   if(recvfrom(s_fd, &ack, sizeof(Packet), 0, NULL, NULL) < 0){
	      if(errno == EWOULDBLOCK){
		 fprintf(stderr, "Cannot detect server\n");
		 exit(EXIT_FAILURE);
	      } else{
	         fprintf(stderr, "Error in recvfrom() for client...\n");
	         exit(EXIT_FAILURE);
              }
	   }

	   recv_pack[ack.seq_number] = ack; 
	   
           if(ack.seq_number == seq_num){
              fwrite(buff, 1, read_bite, out);
	      seq_num++;
	   }
     }

     // Reassembling of packets
     int loss = 0; 
     for(int i = 0; i < num_packets; i++){
         //fwrite(recv_pack[i].data, 1, strlen(recv_pack[i].data), out); 
	 if(send_pack[i].seq_number != recv_pack[i].seq_number){
	    fprintf(stderr, "Packet loss!\n");
	    loss = 1;
	 }
     }
     if(loss){
	exit(EXIT_FAILURE);
     }
}

int main(int arg, char *argv[]){
     if(arg != 6){
	fprintf(stderr, "Usage: %s <IP> <port> <MTU> <in_file_path> <out_file_path>\n", argv[0]);
        exit(EXIT_FAILURE);
     }
     printf("size of packet: %ld\n", sizeof(Packet));
     struct sockaddr_in client_addr;
     int s_fd_client, port_num, mtu; 
     
     const char *IP = argv[1];
     port_num = atoi(argv[2]);
     mtu = atoi(argv[3]);

     if(mtu <= (int)sizeof(Packet)){
	fprintf(stderr, "Required minimum MTU is MAXLINE + 1\n");
        exit(EXIT_FAILURE);
     }

     const char *in_file_s = argv[4];
     const char *out_file_s = argv[5];
     
     // UDP Client Constraints
     memset(&client_addr, 0, sizeof(client_addr));
     client_addr.sin_family = AF_INET;
     client_addr.sin_port = htons(port_num);

     // Setting Client Socket
     if((s_fd_client = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
         fprintf(stderr, "Error in socket\n");
         exit(EXIT_FAILURE);
    }

    if(inet_pton(AF_INET, IP, &client_addr.sin_addr) <= 0){
       fprintf(stderr, "Error in IP address validity\n");
       exit(EXIT_FAILURE);
    }

    FILE *in_file = fopen(in_file_s, "rb");     
    if(in_file == NULL){
       fprintf(stderr, "Error in reading file\n");
       exit(EXIT_FAILURE);
    }
    
    FILE *out_file = fopen(out_file_s, "wb");
    if(out_file == NULL){
       fprintf(stderr, "Error writing file\n");
       exit(EXIT_FAILURE);
    }

    // call on the client echo, which will carry the input arg and MTU
    DG_CLI(in_file, out_file, s_fd_client, mtu, (const struct sockaddr *)&client_addr, sizeof(client_addr));
    fclose(in_file);
    fclose(out_file);
    close(s_fd_client);
    return 0;
}
