#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#define MAXLINE         32000    /* max test line length */

// Data Structure for packet ordering, as per ed discussion
typedef struct Packet {
     int seq_number;
} Packet;

// Inspiration from 8.4 in Unix Textbook
void dg_echo(int s_fd){
     struct sockaddr_in cli_addr;
     socklen_t cli_addr_len = sizeof(cli_addr);
     ssize_t data; 
     char buff[MAXLINE];

     for( ; ; ){
         if((data = recvfrom(s_fd, buff, MAXLINE, 0, (struct sockaddr *)&cli_addr, &cli_addr_len)) < 0){
	    fprintf(stderr, "Error in recvfrom()\n");
            exit(EXIT_FAILURE);
         }

	 printf("Received %zd bytes from client\n", data);
         Packet *recv_pack = (Packet *)buff;
 
	 Packet ack;
         ack.seq_number = recv_pack->seq_number; 

         if(sendto(s_fd, &ack, sizeof(ack), 0, (struct sockaddr *)&cli_addr, cli_addr_len) < 0){
	    fprintf(stderr, "Error in sendto()\n");
	    exit(EXIT_FAILURE);
         }

	 printf("Sent %zd bytes back to client\n", data);
 
     }
}

int main(int arg, char *argv[]){
    if(arg != 2){
       fprintf(stderr, "Usage: %s <port>\n", argv[0]); 
       exit(EXIT_FAILURE);
    }
    struct sockaddr_in server_addr; 
    int s_fd_server, in_port, n_b; 
    in_port = atoi(argv[1]);

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(in_port);

    // Set up of Server 
    if((s_fd_server = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
	fprintf(stderr, "Error in socket\n");
        exit(EXIT_FAILURE);
    }

    if((n_b = bind(s_fd_server, (struct sockaddr *)&server_addr, sizeof(server_addr))) == -1){
       fprintf(stderr, "Error in bind\n");
       exit(EXIT_FAILURE);
    }
    // calls dg_echo to connect multiple client(s) to server

    dg_echo(s_fd_server);
    close(s_fd_server);
    return 0;
}
