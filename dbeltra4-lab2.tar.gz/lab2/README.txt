# README for CSE 156/L: Lab2 Simple Echo File

## Name: Daniel Beltran
## ID: 1802452

## List of files:
 - Makefile
 - src/myclient.c
 - src/myserver.c
 - README.txt 
---------------------------------------------------------------------
The myclient.c and myserver.c are two files that are ran together
for the purpose of echo file transfer. The server side takes the 
input of <port_number>, which will allow the client side to listen
into the port. The client side will provide inputs of the host IP, 
port to listen into, the MTU size, and the input/output. 

To get better insights of the files, the Documentation.pdf will go
more into detail in doc/

