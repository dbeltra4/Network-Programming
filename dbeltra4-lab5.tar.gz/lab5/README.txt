# README for CSE 156/L: Lab5 Client-to-Server Proxy

## Name: Daniel Beltran
## ID: 1802452

## List of files:
 - Makefile
 - src/myproxy.c
 - README.txt 
---------------------------------------------------------------------
The myproxy file serves as the proxy that will be used for processing client
requests to the server and returning the response. This lab is intended to be
multi-threaded and undergo many functionalites as listed in the instructions
(forbidden files, parsing, logging, etc). The whole premise of this assignment
is to have some client (ex. curl commmand) that will send either a GET or HEAD
request to proxy to then the server in which it will be returned back to the
client.

To get better insights of the files, the Documentation.pdf will go
more into detail in doc/

