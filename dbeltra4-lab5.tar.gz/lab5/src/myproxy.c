#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <sys/stat.h>
#include <signal.h>
#include <pthread.h>
/* OpenSSL Headers */
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/bio.h>

#define MAXLINE 1024
pthread_mutex_t forbid_mutex;
pthread_mutex_t file_mutex;
pthread_mutex_t blocked_mutex;

void create_dir(const char *full_path){
     char dir_path[256];
     strncpy(dir_path, full_path, 256);
     char *slash = strrchr(dir_path, '/');

     if(slash != NULL){
	     *slash = '\0';
        struct stat st = {0};
        if(stat(dir_path, &st) == -1){
	        if(mkdir(dir_path, 0700) == -1){
	           fprintf(stderr, "Error making directory\n");
	           exit(EXIT_FAILURE);
	        }
        }
     }
}

void access_log(const char *access_log_path, int s_fd_cli, const char *request_line, int status_code, int response_size){
    pthread_mutex_lock(&file_mutex);
    time_t current_time;
    struct tm *time_info;
    char timestamp[64];
    struct timeval tv;

    char client_ip[INET_ADDRSTRLEN];
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    getpeername(s_fd_cli, (struct sockaddr *)&client_addr, &addr_len);
    inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, INET_ADDRSTRLEN);

    gettimeofday(&tv, NULL);
    current_time = tv.tv_sec;
    time_info = gmtime(&current_time);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%dT%H:%M:%S", time_info);

    FILE *access_log_file = fopen(access_log_path, "a");
    if(access_log_file == NULL){
       fprintf(stderr, "Failed to open access log file path\n");
       pthread_mutex_unlock(&file_mutex);
       return;
    }

    int ms = tv.tv_usec / 1000;
    fprintf(access_log_file,"%s.%03dZ %s \"%s\" %d %d\n", timestamp, ms, client_ip, request_line, status_code, response_size);
    fclose(access_log_file);
    pthread_mutex_unlock(&file_mutex);
}

char forbidden_sites_file_path[MAXLINE]; // Global Variable
char blocked_sites[MAXLINE][MAXLINE];
int num_blocked_sites = 0;

int is_forbidden(char *URL){
    for(int i = 0; i < num_blocked_sites; i++){
	if(strcmp(URL, blocked_sites[i]) == 0){
           return 1;
	}
    }
    return 0;
}

struct ProxyArgs {
    int s_fd_cli;
    char access_log_path[MAXLINE];
};
void *handle_proxy(void *arg){
     struct ProxyArgs *proxy_args = (struct ProxyArgs *)arg;
     int s_fd_cli = proxy_args->s_fd_cli;
     const char *access_log_path = proxy_args->access_log_path;

     char buff[MAXLINE];
     ssize_t read_bite; 
     if((read_bite = recv(s_fd_cli, buff, MAXLINE, 0)) < 0){
	 fprintf(stderr, "Error in recv()\n");
         exit(EXIT_FAILURE);
     }
     buff[read_bite] = '\0';
     
     // Process HTTP Request headers
     char method[16], URI[MAXLINE], http_version[16];
     char *header_end = strstr(buff, "\r\n");
     if(header_end == NULL){
	fprintf(stderr, "Invalid request: missing CRLF terminator\n");
	close(s_fd_cli);
        free(proxy_args);
        return NULL;
     }
     *header_end = '\0';
     header_end += 2;
 
     if(sscanf(buff, "%15s %s %15s", method, URI, http_version) != 3){
	const char *error_response = "HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n";
	send(s_fd_cli, error_response, strlen(error_response), 0);
	access_log(access_log_path, s_fd_cli, buff, 400, read_bite);
     } else {
	printf("HTTP Version: %s\n", http_version);
     }

     char request_line[MAXLINE + 100];
     snprintf(request_line, sizeof(request_line), "%s %s %s", method, URI, http_version);

     if(strcmp(http_version, "HTTP/1.1") != 0){
    	const char *error_response = "HTTP/1.1 505 HTTP Version Not Supported\r\nConnection: close\r\n\r\n";
    	send(s_fd_cli, error_response, strlen(error_response), 0);
    	access_log(access_log_path, s_fd_cli, request_line, 505, read_bite);
    	close(s_fd_cli);
    	free(proxy_args);
    	return NULL;
     }

     printf("Request line: %s %s %s\n", method, URI, http_version);
     access_log(access_log_path, s_fd_cli, request_line, 200, read_bite);

     /*--------501 Status--------*/
     if(strcmp(method, "CONNECT") == 0) {
    	const char *connect_error_response = "HTTP/1.1 501 Not Implemented\r\nContent-Length: 0\r\n\r\n";
    	send(s_fd_cli, connect_error_response, strlen(connect_error_response), 0);
    	access_log(access_log_path, s_fd_cli, request_line, 501, strlen(connect_error_response));
     }
     if((strcmp(method, "GET") != 0) && (strcmp(method, "HEAD") != 0)){
	 const char *error_response = "HTTP/1.1 501 Not Implemented\r\nContent-Length: 0\r\n\r\n";
         send(s_fd_cli, error_response, strlen(error_response), 0);
         access_log(access_log_path, s_fd_cli, request_line, 501, read_bite);
     } 
     /*-------------------------*/

     int port = 443; // default https
     char *saveptr;
     char *host; 
     char *end;
     if((end = strstr(URI, "://")) != NULL){
	host = strtok_r(end + 3, ":/", &saveptr);
     }else{
	host = strtok_r(URI, ":/", &saveptr);
     }
      
     char *port_str = strtok_r(NULL, ":/", &saveptr);
     if (port_str != NULL) {
        port = atoi(port_str);
     }
     printf("Host: %s, Port: %d\n", host, port); 
 
     pthread_mutex_lock(&blocked_mutex);    
     /*--------403 Status--------*/ 
     int forbidden = is_forbidden(host);
     printf("is_forbidden(%s) returned: %d\n", host, forbidden);
     if(forbidden == 1){
	const char *error_response = "HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n";
        send(s_fd_cli, error_response, strlen(error_response), 0);
        access_log(access_log_path, s_fd_cli, request_line, 403, read_bite);
        close(s_fd_cli);
        return NULL;
     }
     pthread_mutex_unlock(&blocked_mutex);

     // DNS Logic
     struct addrinfo hints, *serv_info, *rp;
     memset(&hints, 0, sizeof(hints));
     hints.ai_family = AF_UNSPEC;
     hints.ai_socktype = SOCK_STREAM;

     int stat;
     if((stat = getaddrinfo(host, NULL, &hints, &serv_info)) != 0){
	 fprintf(stderr, "Error in getaddrinfo: %s\n", gai_strerror(stat));
    	 const char *error_response = "HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n";
    	 send(s_fd_cli, error_response, strlen(error_response), 0);
    	 access_log(access_log_path, s_fd_cli, request_line, 502, read_bite);
         close(s_fd_cli);
    	 free(proxy_args);
    	 return NULL;
     }

     struct sockaddr_in host_addr;
     memset(&host_addr, 0, sizeof(host_addr));
     host_addr.sin_family = AF_INET;
     host_addr.sin_port = htons(port);

     int s_fd_host;
     if((s_fd_host = socket(AF_INET, SOCK_STREAM, 0)) < 0){
	 fprintf(stderr, "Error with host socket\n");
	 const char *error_response = "HTTP/1.1 504 Gateway Timeout\r\nContent-Length: 0\r\n\r\n";
         send(s_fd_cli, error_response, strlen(error_response), 0);
         access_log(access_log_path, s_fd_cli, request_line, 504, read_bite);
         exit(EXIT_FAILURE);
     }

     char ip_check[INET6_ADDRSTRLEN];
     for(rp = serv_info; rp != NULL; rp = rp->ai_next){
         void* addr_ptr; 
 	 if(rp->ai_family == AF_INET){
	    struct sockaddr_in *ipv4 = (struct sockaddr_in *)rp->ai_addr;
 	    addr_ptr = &(ipv4->sin_addr);
         } else{
	    fprintf(stderr, "rp: Unsupported address family\n"); 
         }    

         inet_ntop(rp->ai_family, addr_ptr, ip_check, sizeof(ip_check)); 
         
         pthread_mutex_lock(&blocked_mutex);
         int forbidden_ip = is_forbidden(ip_check);
         printf("INSIDE LOOP: is_forbidden(%s) returned: %d\n", ip_check, forbidden_ip);
	 if(forbidden_ip == 1){
	    const char *error_response = "HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n";
            send(s_fd_cli, error_response, strlen(error_response), 0);
            access_log(access_log_path, s_fd_cli, request_line, 403, read_bite);
            pthread_mutex_unlock(&blocked_mutex);
            freeaddrinfo(serv_info);
            close(s_fd_cli);
            return NULL;
         }
         pthread_mutex_unlock(&blocked_mutex);
     }

     struct in_addr addr;
     if(inet_pton(AF_INET, host, &addr) == 1){
	host_addr.sin_addr = addr;
     } else{
	   if(serv_info->ai_family == AF_INET){
              struct sockaddr_in *ipv4 = (struct sockaddr_in *)serv_info->ai_addr;
              memcpy(&host_addr.sin_addr, &ipv4->sin_addr, sizeof(struct in_addr));
           } else{
              fprintf(stderr, "Unsupported address family\n");
           }
     }

     if(connect(s_fd_host, (struct sockaddr *)&host_addr, sizeof(host_addr)) == -1){
	fprintf(stderr, "Error with connect()\n");
        const char *error_response = "HTTP/1.1 504 Gateway Timeout\r\nContent-Length: 0\r\n\r\n";
        send(s_fd_cli, error_response, strlen(error_response), 0);
        access_log(access_log_path, s_fd_cli, request_line, 504, read_bite);
	exit(EXIT_FAILURE);
     }

     SSL_CTX *ctx = SSL_CTX_new(SSLv23_client_method());

     if(!ctx){
	fprintf(stderr, "Error in ctx\n");
	close(s_fd_cli);
	free(proxy_args);
	return NULL;
     }

     // Sets the mode and retries 
     SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY);
     SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);

     SSL *server_ssl = SSL_new(ctx);
     if(!server_ssl){
	fprintf(stderr, "Error in ssl\n");
	close(s_fd_host);
	free(proxy_args);
	SSL_CTX_free(ctx);	
	return NULL;
     }

     if(!SSL_set_fd(server_ssl, s_fd_host)){
	fprintf(stderr, "Error in setting SSL file descriptor.\n");
	close(s_fd_host);
	free(proxy_args);
	SSL_free(server_ssl);
        SSL_CTX_free(ctx);
	return NULL;
     }

     // Load certificates from the Unix
     if(!SSL_CTX_load_verify_locations(ctx, "/etc/pki/tls/cert.pem", NULL)){
	fprintf(stderr, "Incorrect loading of CA files\n");
        exit(EXIT_FAILURE);
     }

     if(SSL_connect(server_ssl) < 0){
	fprintf(stderr, "Error in SSL_connect()\n");
	close(s_fd_host);
        free(proxy_args);
        SSL_free(server_ssl);
        SSL_CTX_free(ctx);
        return NULL;
     }
      
     // Gets the peer certificate
     X509 *cert;
     if((cert = SSL_get_peer_certificate(server_ssl)) == NULL){
	 fprintf(stderr, "Could not receive certificate\n");
	 exit(EXIT_FAILURE);
     }

     if(SSL_get_verify_result(server_ssl) !=  X509_V_OK){
	fprintf(stderr, "Could not verify certificate\n");
	exit(EXIT_FAILURE);
     }

     char modified_request[MAXLINE + 100];
     sprintf(modified_request, "%s\r\n\r\n", buff);

     if(SSL_write(server_ssl, modified_request, strlen(modified_request)) <= 0){
	fprintf(stderr, "Error with SSL_write()\n");
	close(s_fd_cli);
        close(s_fd_host);
        SSL_shutdown(server_ssl);
        SSL_free(server_ssl);
        SSL_CTX_free(ctx);
        free(proxy_args);
        return NULL;
     }

     char send_buff[MAXLINE];
     ssize_t total_response_size = 0;
     ssize_t send_bite;
     while((read_bite = SSL_read(server_ssl, send_buff, MAXLINE)) > 0){
	    send_buff[read_bite] = '\0';
	    if((send_bite = send(s_fd_cli, send_buff, read_bite, 0)) < 0){
	        fprintf(stderr, "Error in send()\n");
	        exit(EXIT_FAILURE);
	    }
	    total_response_size += send_bite;
     }
 
     if(read_bite == 0){
	printf("SSL connection closed by server\n");
     } else if (read_bite < 0){
	fprintf(stderr, "Error in SSL_read()\n");
     }
     access_log(access_log_path, s_fd_cli, request_line, 200, total_response_size);

     close(s_fd_host);
     freeaddrinfo(serv_info);
     SSL_shutdown(server_ssl);
     SSL_free(server_ssl);
     SSL_CTX_free(ctx);
     close(s_fd_cli);
     free(proxy_args);
     return NULL;
}

void proxy_update(int sig){
     pthread_mutex_lock(&forbid_mutex);
     printf("Received SIGINT. Reloading forbidden sites file...\n");
     
     FILE *forbid_sites = fopen(forbidden_sites_file_path, "r");
     if(forbid_sites == NULL){
        fprintf(stderr, "Failed to open forbidden sites file path\n");
        exit(EXIT_FAILURE);
     }

     num_blocked_sites = 0;
     char line[MAXLINE];
     while(fgets(line, sizeof(line), forbid_sites) != NULL){
	   line[strcspn(line, "\n")] = '\0';
           strcpy(blocked_sites[num_blocked_sites], line);
	   num_blocked_sites++;
     }
 
     for(int i = 0; i < num_blocked_sites; i++){
	printf("%s\n", blocked_sites[i]);
     }
     fclose(forbid_sites); 
     pthread_mutex_unlock(&forbid_mutex); 
}

int main(int argc, char *argv[]){
    if(argc != 4){
       fprintf(stderr, "Usage: %s <listen_port> <forbidden_sites_file_path> <access_log_file_path>\n", argv[0]);
       exit(EXIT_FAILURE);
    }
    SSL_library_init(); 
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();

    pthread_mutex_init(&forbid_mutex, NULL);
    pthread_mutex_init(&file_mutex, NULL);
    pthread_mutex_init(&blocked_mutex, NULL);

    int s_fd_serv, s_fd_cli;
    struct sockaddr_in serv_proxy_addr, client_addr;
    

    if((s_fd_serv = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        fprintf(stderr, "Error in socket creation\n");
        exit(EXIT_FAILURE);
    }
    memset(&serv_proxy_addr, 0, sizeof(serv_proxy_addr));
    serv_proxy_addr.sin_family = AF_INET;
    serv_proxy_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_proxy_addr.sin_port = htons(atoi(argv[1]));

    if(bind(s_fd_serv, (struct sockaddr *)&serv_proxy_addr, sizeof(serv_proxy_addr)) < 0){
        fprintf(stderr, "Error in binding\n");
        exit(EXIT_FAILURE);
    }
  
    if(listen(s_fd_serv, SOMAXCONN) == -1){
       fprintf(stderr, "Failed to listen\n");
       exit(EXIT_FAILURE);
    }

    char access_log_file_path[MAXLINE];

    strcpy(forbidden_sites_file_path, argv[2]);
    create_dir(forbidden_sites_file_path);
    strcpy(access_log_file_path, argv[3]);
    create_dir(access_log_file_path);

    struct sigaction sa;
    sa.sa_flags = 0;
    sa.sa_handler = &proxy_update;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    proxy_update(0);
    for(;;){
	socklen_t client_addr_len = sizeof(client_addr);
	if((s_fd_cli = accept(s_fd_serv, (struct sockaddr *)&client_addr, &client_addr_len)) < 0){
	       fprintf(stderr, "Error in accept\n");
	       exit(EXIT_FAILURE);
	} 
        struct ProxyArgs *proxy_args = (struct ProxyArgs *)malloc(sizeof(struct ProxyArgs));
        if(proxy_args == NULL){
	   fprintf(stderr, "Error in proxy_args\n");
	   exit(EXIT_FAILURE);
	}
        proxy_args->s_fd_cli = s_fd_cli;
	strcpy(proxy_args->access_log_path, access_log_file_path);   

        pthread_t tid;
        int c; 
        if((c = pthread_create(&tid, NULL, handle_proxy, proxy_args)) < 0){
	    fprintf(stderr, "Error creating thread\n");
	    exit(EXIT_FAILURE);
	}
        int d;
        if((d = pthread_detach(tid)) < 0){
	    fprintf(stderr, "Error detaching thread\n");
	    exit(EXIT_FAILURE);
	}	
    }

    // End of the logging
    pthread_mutex_destroy(&forbid_mutex);
    pthread_mutex_destroy(&file_mutex);
    pthread_mutex_destroy(&blocked_mutex);
    close(s_fd_serv);
    return 0;
}
