# README for CSE 156/L: Lab4 Concurrent Reliable File Transfer

## Name: Daniel Beltran
## ID: 1802452

## List of files:
 - Makefile
 - src/myclient.c
 - src/myserver.c
 - README.txt 
---------------------------------------------------------------------
The myclient.c and myserver.c are two files that are ran together
for the purpose of reliable file transfer. The server side takes the 
input of <port_number>, <droppc>, and <root_folder_path> which will allow 
the client side to listen into the port. The client side will provide inputs 
of the host IP, port to listen into, the MTU size, and the input/output.
The myclient file will take an extra input of <window_size> as we want to 
implement some protocol for handling file transfer. It essentially covers
the same concepts as lab 3 with the addition to multi-threading. In order for 
one client to communicate to multiple servers, concurrency must be supported. 

To get better insights of the files, the Documentation.pdf will go
more into detail in doc/

