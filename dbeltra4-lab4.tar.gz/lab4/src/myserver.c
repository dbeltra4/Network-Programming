#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define MAX_PACKET_SIZE 32000
#define EOF_NUM -1

typedef struct Packet {
    int seq_number;
    size_t d_len;
    char data[MAX_PACKET_SIZE];
} Packet;

void msg_log(char* lport, char* rip, char* rport, char* msg_type, int pktsn) {
    struct timeval t; 
    time_t cur_time;
    char timestamp[64];
    
    gettimeofday(&t, NULL);
    
    cur_time = t.tv_sec;
    struct tm* time_info = gmtime(&cur_time);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%dT%H:%M:%S", time_info);

    int ms = (t.tv_usec / 1000);
    printf("%s.%03dZ, %s, %s, %s, %s, %d\n", timestamp, ms, lport, rip, rport, msg_type, pktsn);
}

void create_dir(const char *full_path){
     char dir_path[256];
     strncpy(dir_path, full_path, 256);
     char *slash = strrchr(dir_path, '/');

     if(slash != NULL){
	*slash = '\0';
        struct stat st = {0};
        if(stat(dir_path, &st) == -1){
	   if(mkdir(dir_path, 0700) == -1){
	      fprintf(stderr, "Error making directory\n");
	      exit(EXIT_FAILURE);
	   }
        }
     }
}

void dg_serv(int s_fd, int droppc, char* root_folder_path, struct sockaddr_in serv_addr){
     struct sockaddr_in cli_addr;
     socklen_t cli_addr_len = sizeof(cli_addr);
     char out_file[256];
     char full_path[512];
     
     srand(time(NULL));

     if(recvfrom(s_fd, out_file, sizeof(out_file), 0, (struct sockaddr *)&cli_addr, &cli_addr_len) < 0){
        fprintf(stderr, "Error receiving file path from client\n");
        exit(EXIT_FAILURE);
     }
 
     snprintf(full_path, sizeof(full_path), "%s/%s", root_folder_path, out_file);
     printf("Saving file to: %s\n", full_path);
     
     FILE *file = fopen(full_path, "wb");  
     if(file == NULL){
	create_dir(full_path);
	file = fopen(full_path, "wb");
        if(file == NULL){
           fprintf(stderr, "Error opening output file for writing\n");
           exit(EXIT_FAILURE);
        }
     }
     Packet recv_pack;
     int eof_recv = 0;
     ssize_t data;
     char serv_port[6], cli_port[6], cli_ip[INET_ADDRSTRLEN];
     inet_ntop(AF_INET, &cli_addr.sin_addr, cli_ip, INET_ADDRSTRLEN);
     for(;;){
	 if((data = recvfrom(s_fd, &recv_pack, sizeof(Packet), 0, NULL, NULL)) < 0){
            fprintf(stderr, "Error in recvfrom()\n");
            exit(EXIT_FAILURE);
         }
         sprintf(cli_port, "%d", ntohs(cli_addr.sin_port));
         sprintf(serv_port, "%d", ntohs(serv_addr.sin_port));

         if(recv_pack.seq_number == EOF_NUM){
	    eof_recv = 1;
	    printf("EOF packet received. Preparing to send EOF ACK.\n");
	    Packet eof_ack_pack;
	    eof_ack_pack.seq_number = EOF_NUM;
	    eof_ack_pack.d_len = 0;
	    printf("Sending EOF ACK with seq_number: %d\n", eof_ack_pack.seq_number);

	    if(sendto(s_fd, &eof_ack_pack, sizeof(Packet), 0, (struct sockaddr *)&cli_addr, cli_addr_len) < 0){
               fprintf(stderr, "Error sending EOF acknowledgment\n");
	       exit(EXIT_FAILURE);
            }else{
	       printf("Sent EOF acknowledgment\n");
	    }   
	   break;
	} else{
	    // Drop packet logic
	    printf("Packet sequence number: %d\n", recv_pack.seq_number);
	    if((rand() % 101) < droppc){
                if(recv_pack.d_len > 0){ 
                   msg_log(serv_port, cli_ip, cli_port, "DROP DATA", recv_pack.seq_number);
		   continue;
                }else{
	           msg_log(serv_port, cli_ip, cli_port, "DROP ACK", recv_pack.seq_number);
		   continue;
	        }
             }  

	    // DATA && ACK
	    if(recv_pack.d_len > 0){
               fwrite(recv_pack.data, 1, recv_pack.d_len, file); 
               msg_log(serv_port, cli_ip, cli_port, "DATA", recv_pack.seq_number);
            } 
   
	    Packet ack_pack;
	    ack_pack.seq_number = recv_pack.seq_number;
	    memset(ack_pack.data, 0, MAX_PACKET_SIZE);
            ack_pack.d_len = recv_pack.d_len;
	    if(sendto(s_fd, &ack_pack, sizeof(Packet), 0, (struct sockaddr *)&cli_addr, cli_addr_len) < 0){
               fprintf(stderr, "Error sending acknowledgment\n");
            }else{
	       msg_log(serv_port, cli_ip, cli_port, "ACK", recv_pack.seq_number);
	    }
	}
        if(eof_recv){
	   break;
	 }
     }
     fclose(file);
}

int main(int argc, char *argv[]){
    if (argc != 4){
        fprintf(stderr, "Usage: %s <port> <droppc> <root_folder_path>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int s_fd_server, in_port, droppc;
    
    in_port = atoi(argv[1]);
    droppc = atoi(argv[2]);
    char *root_folder_path = argv[3];
 
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(in_port);

    if((s_fd_server = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
        fprintf(stderr, "Error in socket creation\n");
        exit(EXIT_FAILURE);
    }

    if(bind(s_fd_server, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0){
        fprintf(stderr, "Error in binding\n");
        close(s_fd_server);
        exit(EXIT_FAILURE);
    }
    dg_serv(s_fd_server, droppc, root_folder_path, server_addr);

    close(s_fd_server);

    return 0;
}
