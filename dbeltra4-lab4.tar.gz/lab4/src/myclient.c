#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <pthread.h>

#define MAXLINE         1450 
#define MAX_RETRANSMIT  10
#define MAX_WINDOW_SIZE 1024
#define EOF_NUM -1

pthread_mutex_t socket_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t file_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t next_sn_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t base_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    int seq_number;
    size_t d_len;
    char data[MAXLINE];
} Packet;

typedef struct {
    char ip[16];
    int port;
} serv_info;

void msg_log(char* lport, char* rip, char* rport, char* pkt_type, int pktsn, int basesn, int nextsn, int winsz) {
    time_t cur_time;
    char timestamp[64];
    struct timeval tv;

    gettimeofday(&tv, NULL);
    cur_time = tv.tv_sec;

    struct tm* time_info = gmtime(&cur_time);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%dT%H:%M:%S", time_info);
    
    int ms = tv.tv_usec / 1000;
    printf("%s.%03dZ, %s, %s, %s, %s, %d, %d, %d, %d\n",timestamp,ms,lport,rip,rport,pkt_type,pktsn,basesn,nextsn,basesn+winsz);

}

typedef struct{
    int s_fd;
    int* s_fd_ptr;
    struct sockaddr* pservaddr;
    socklen_t servlen;
    int mtu;
    int winsz;
    FILE* in_file;
    const char* in;
    const char* out;
} ThreadArgs;

void* cli_send_data(void* arg){
      ThreadArgs* args = (ThreadArgs*)arg;
      int s_fd = args->s_fd;
      struct sockaddr* pservaddr = args->pservaddr;
      socklen_t servlen = args->servlen;
      int mtu = args->mtu;
      int winsz = args->winsz;
      FILE* in_file = args->in_file;
      const char* in = args->in;
      const char* out = args->out;
      
      struct timeval t;
      t.tv_sec = 30;
      t.tv_usec = 0;
      if(setsockopt(s_fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof(t)) < 0){
         fprintf(stderr, "Error in setsockopt()\n");
         exit(EXIT_FAILURE);
      }

      char serv_port[6], cli_port[6], cli_ip[INET_ADDRSTRLEN]; 
      struct sockaddr_in serv_tmp;
      memcpy(&serv_tmp, pservaddr, sizeof(struct sockaddr_in));

      pthread_mutex_lock(&file_mutex);

      in_file = fopen(in, "rb");     
      if(in_file == NULL){
         fprintf(stderr, "Error in reading file\n");
         exit(EXIT_FAILURE);
      }

      fseek(in_file, 0, SEEK_END);
      long f_size = ftell(in_file);
      rewind(in_file);
      int num_packets = (f_size + mtu - 1) / mtu;

      pthread_mutex_unlock(&file_mutex);

      if(sendto(s_fd, out, strlen(out) + 1, 0, pservaddr, servlen) < 0){
         fprintf(stderr, "Error sending file path to server\n");
         exit(EXIT_FAILURE);
      }
      Packet P[MAXLINE];
      int next_sn = 0;
      int base = 0;
      size_t read_bite;

      int retransmit[num_packets];
      memset(retransmit, 0, sizeof(retransmit));
      printf("Number of packets to send: %d\n", num_packets);
      pthread_mutex_lock(&base_mutex);
      while(base < num_packets){
	    struct sockaddr_in local_addr;
    	    socklen_t local_len = sizeof(local_addr);
    	    getsockname(s_fd, (struct sockaddr*)&local_addr, &local_len);
    	    int cli_port_num = ntohs(local_addr.sin_port);
    	    sprintf(cli_port, "%d", cli_port_num);
	    
	    int serv_port_num = ntohs(serv_tmp.sin_port);
    	    sprintf(serv_port, "%d", serv_port_num);
    	    inet_ntop(AF_INET, &serv_tmp.sin_addr, cli_ip, INET_ADDRSTRLEN);

	    pthread_mutex_lock(&next_sn_mutex);
            while((next_sn  < base + winsz) && (next_sn < num_packets)){
		   Packet p;
	           read_bite = fread(p.data, 1, mtu, in_file);
		   p.seq_number = next_sn;
	           p.d_len = read_bite;
		   
		   printf("Sending packet %d with data length %zu\n", p.seq_number, p.d_len);

		   P[next_sn % MAXLINE] = p;
		   if(sendto(s_fd, &p, sizeof(Packet) + p.d_len, 0, pservaddr, servlen) < 0){
                      fprintf(stderr, "Error in sendto() for client...\n");
                      exit(EXIT_FAILURE);
                   }
		   msg_log(serv_port, cli_ip, cli_port, "DATA", p.seq_number, base, next_sn, base + winsz);
		   next_sn++;
	    }
	    pthread_mutex_unlock(&next_sn_mutex);
	    
	    Packet Ack;
	    ssize_t ack_len;
	    if((ack_len = recvfrom(s_fd, &Ack, sizeof(Packet), 0, NULL, NULL)) < 0){
		if(errno == EAGAIN || errno == EWOULDBLOCK){
		   fprintf(stderr, "Timeout occurred. No acknowledgment received. Retransmitting...\n");

	        int max_reached = 0;	
	  	for(int i = base; i < next_sn; i++){
		    if(retransmit[i] < 10){
		       if(retransmit[i] >= 3){
		          fprintf(stderr, "Retransmitting packet %d (attempt %d)...\n", i, retransmit[i] + 1);
		       }
		       if(sendto(s_fd, &P[i % MAXLINE], sizeof(Packet), 0, pservaddr, servlen) < 0){
                            fprintf(stderr, "Error in sendto() for client...\n");
                            exit(EXIT_FAILURE);
                       }
		       msg_log(serv_port, cli_ip, cli_port, "DATA", P[i % MAXLINE].seq_number, base, next_sn, base + winsz);
		       retransmit[i]++;
		    }else{
		       //fprintf(stderr, "Reached max re-transmission limit for packet %d\n", i);
		       fprintf(stderr, "Reached maximum retransmission\n");
		       max_reached = 1;
		    }
	          
		}
                if(max_reached){
		   exit(EXIT_FAILURE);
		}

	      }else{
		       fprintf(stderr, "Error in recvfrom() for client\n");
                       exit(EXIT_FAILURE);
	       } 

	  }else{
	       if(ack_len >= 0 && Ack.seq_number >= base && Ack.seq_number < base + winsz){
		  msg_log(serv_port, cli_ip, cli_port, "ACK", Ack.seq_number, base, next_sn, base + winsz);
		  base = Ack.seq_number + 1;
		}else{
		   fprintf(stderr, "Received incorrect acknowledgment for packet %d. Ignoring...\n", Ack.seq_number);
		}
	   }
       }
       pthread_mutex_unlock(&base_mutex);
       // EOF Logic 
       Packet EF;
       EF.seq_number = EOF_NUM;
       EF.d_len = 0;
       printf("EF.d_len = %ld\n", EF.d_len);
       if(sendto(s_fd, &EF, sizeof(Packet), 0, pservaddr, servlen) < 0){
          fprintf(stderr, "Error in sendto(EF) for client...\n");
          exit(EXIT_FAILURE);
       } 
       printf("Sent EOF Packet\n");
       t.tv_sec = 30;
       if(setsockopt(s_fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof(t)) < 0){
          fprintf(stderr, "Error in setsockopt()\n");
          exit(EXIT_FAILURE);
       } 
       Packet EF_ack;
       int recv_ack; 
       if((recv_ack = recvfrom(s_fd, &EF_ack, sizeof(Packet), 0, NULL, NULL)) < 0){
	  if(errno == EWOULDBLOCK || errno == EAGAIN){
             fprintf(stderr, "Timeout occurred. No acknowledgment received.\n");
             exit(EXIT_FAILURE);	
	  } else{
             fprintf(stderr, "Error in recvfrom() for client...\n");
             exit(EXIT_FAILURE);     
          } 
      } else{
    	   printf("Received acknowledgment for EOF packet\n");
      }
      fclose(in_file);
      free(args->pservaddr);
      free(args); 
      return NULL;
}


int main(int arg, char *argv[]){
     if(arg != 7){
	fprintf(stderr, "Usage: %s <servn> <servaddr.conf> <mtu> <winsz> <in_file_path> <out_file_path>\n", argv[0]);
        exit(EXIT_FAILURE);
     }
     printf("size of packet: %ld\n", sizeof(Packet));
     int s_fd_client, mtu, winsz, servn; 
     
     servn = atoi(argv[1]);
     const char *serv_conf = argv[2];  
     mtu = atoi(argv[3]);
     winsz = atoi(argv[4]);
     const char *in_file_s = argv[5];
     const char *out_file_s = argv[6];

     if(mtu <= (int)sizeof(Packet)){
	fprintf(stderr, "Required minimum MTU is MAXLINE + 1\n");
        exit(EXIT_FAILURE);
     }

     if(servn <= 0 || servn > 10){
        fprintf(stderr, "Invalid number of servers\n");
        exit(EXIT_FAILURE);
     }
 
     if(winsz >= MAX_WINDOW_SIZE){
	fprintf(stderr, "Maximum window size exceeded\n");	
	exit(EXIT_FAILURE);
     } 

     FILE *serv_file = fopen(serv_conf, "r");
     if(serv_file == NULL){
        fprintf(stderr, "Error opening server configuration file\n");
        exit(EXIT_FAILURE);
     }

     pthread_mutex_init(&next_sn_mutex, NULL);
     pthread_mutex_init(&base_mutex, NULL);
     pthread_mutex_init(&file_mutex, NULL);

     serv_info serv[10]; 
     int num_serv = 0;
     char line[100];
     while(fgets(line, sizeof(line), serv_file) != NULL && num_serv < 10){
	   if (line[0] == '#') continue;

	   char IP[16];
	   int port_num; 
	   if(sscanf(line, "%s %d", IP, &port_num) != 2){
	      fprintf(stderr, "Invalid format for server configuration file.\n");
	      exit(EXIT_FAILURE);
	   }

	   strcpy(serv[num_serv].ip, IP);
	   serv[num_serv].port = port_num;
	   num_serv++;

    }
    fclose(serv_file);
    
    FILE *out_file = fopen(out_file_s, "wb");
    if(out_file == NULL){
       fprintf(stderr, "Error writing file\n");
       exit(EXIT_FAILURE);
    }
    
    pthread_mutex_init(&socket_mutex, NULL);
    pthread_t threads[servn];
    printf("Number of servers to replicate to: %d\n", servn);
    for(int j = 0; j < servn; ++j){
	printf("Creating thread for server %d\n", j);
	pthread_mutex_lock(&socket_mutex);
	if((s_fd_client = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
            fprintf(stderr, "Error in socket\n");
            exit(EXIT_FAILURE);
        }
	pthread_mutex_unlock(&socket_mutex);
        ThreadArgs* args = (ThreadArgs*)malloc(sizeof(ThreadArgs));
	args->s_fd = s_fd_client;
	args->mtu = mtu;
        args->winsz = winsz;
        args->in_file = fopen(in_file_s, "rb");
        args->in = in_file_s;
        args->out = out_file_s;
       
	struct sockaddr_in* client_addr = (struct sockaddr_in*)malloc(sizeof(struct sockaddr_in));
	memset(client_addr, 0, sizeof(struct sockaddr_in));
        client_addr->sin_family = AF_INET;
        client_addr->sin_port = htons(serv[j].port);

	if(inet_pton(AF_INET, serv[j].ip, &client_addr->sin_addr) <= 0){
           fprintf(stderr, "Error in IP address validity\n");
           exit(EXIT_FAILURE);
        }

	args->pservaddr = (struct sockaddr*)client_addr;
	args->servlen = sizeof(struct sockaddr_in);

	if(args->in_file == NULL){
            fprintf(stderr, "Error in reading file\n");
            exit(EXIT_FAILURE);
        }
	printf("Server IP: %s, Port: %d\n", serv[j].ip, serv[j].port);
        if(pthread_create(&threads[j], NULL, cli_send_data, (void*)args) != 0){
            fprintf(stderr, "Error creating thread\n");
            exit(EXIT_FAILURE);
        }
	
    }

    for(int i = 0; i < servn; ++i){
        pthread_join(threads[i], NULL);
	ThreadArgs* args = (ThreadArgs*)malloc(sizeof(ThreadArgs));
	*args = *((ThreadArgs*) threads[i]);
        free(args); 
        close(args->s_fd);
    }
    pthread_mutex_destroy(&file_mutex);   
    pthread_mutex_destroy(&socket_mutex);
    pthread_mutex_destroy(&next_sn_mutex);
    pthread_mutex_destroy(&base_mutex);
    fclose(out_file);
    return 0;
}
