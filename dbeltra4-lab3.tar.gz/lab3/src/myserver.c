#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define MAX_PACKET_SIZE 32000 /* max packet size */
#define EOF_SEQ_NUM -1
#define TIMEOUT 15

// Data Structure for packet ordering
typedef struct Packet {
    int seq_number;
    int d_len;
    char data[MAX_PACKET_SIZE];
} Packet;

void msg_log(char* msg_type, int pktsn) {
    struct timeval t; 
    time_t cur_time;
    char timestamp[64];
    
    gettimeofday(&t, NULL);
    
    cur_time = t.tv_sec;
    struct tm* time_info = gmtime(&cur_time);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%dT%H:%M:%S", time_info);

    // Print timestamp and message
    int ms = (t.tv_usec / 1000);
    printf("%s.%03dZ, %s, %d\n", timestamp, ms, msg_type, pktsn);
}

void dg_serv(int s_fd, int droppc) {
    struct sockaddr_in cli_addr;
    socklen_t cli_addr_len = sizeof(cli_addr);
    ssize_t data;
    
    srand(time(0)); // Seed for random number generation

    char out_file[256];
    if((data = recvfrom(s_fd, out_file, sizeof(out_file), 0, (struct sockaddr *)&cli_addr, &cli_addr_len)) < 0) {
        fprintf(stderr, "Error receiving file path from client\n");
        exit(EXIT_FAILURE);
    }
    printf("Received output file path from client: %s\n", out_file);

    FILE *file = fopen(out_file, "wb");  // Open output file for writing in binary mode
    if (file == NULL) {
        fprintf(stderr, "Error opening output file for writing\n");
        exit(EXIT_FAILURE);
    }

    //int exp_seq = 0;  // Expected sequence number
    int eof_recv = 0;
    Packet recv_pack;
    for (;;) {
        if((data = recvfrom(s_fd, &recv_pack, sizeof(Packet), 0, (struct sockaddr *)&cli_addr, &cli_addr_len)) < 0){
            fprintf(stderr, "Error in recvfrom()\n");
            exit(EXIT_FAILURE);
        } 

	if(recv_pack.seq_number == EOF_SEQ_NUM){
	   eof_recv = 1;
	   printf("EOF packet received. Preparing to send EOF ACK.\n");
	   Packet eof_ack_pack;
	   eof_ack_pack.seq_number = EOF_SEQ_NUM;
	   eof_ack_pack.d_len = 0;
	   printf("Sending EOF ACK with seq_number: %d\n", eof_ack_pack.seq_number);

	   if(sendto(s_fd, &eof_ack_pack, sizeof(Packet), 0, (struct sockaddr *)&cli_addr, cli_addr_len) < 0){
              fprintf(stderr, "Error sending EOF acknowledgment\n");
	      exit(EXIT_FAILURE);
           }else{
	      printf("Sent EOF acknowledgment\n");
	   }   
	   break;
	}else{
	     if((rand() % 101) < droppc){
                 if(recv_pack.d_len > 0){ 
                    msg_log("DROP DATA", recv_pack.seq_number);
		    continue;
                 }else{
	            msg_log("DROP ACK", recv_pack.seq_number);
		    continue;
	         }
              }
	      if(recv_pack.d_len > 0){
		     fwrite(recv_pack.data, 1, recv_pack.d_len, file);
	         msg_log("DATA", recv_pack.seq_number);
	     }else{
	         msg_log("ACK", recv_pack.seq_number);
             }
	     Packet ack_pack;
	     ack_pack.seq_number = recv_pack.seq_number;
	     memset(ack_pack.data, 0, MAX_PACKET_SIZE);
             ack_pack.d_len = recv_pack.d_len;
	     if(sendto(s_fd, &ack_pack, sizeof(Packet), 0, (struct sockaddr *)&cli_addr, cli_addr_len) < 0){
                fprintf(stderr, "Error sending acknowledgment\n");
             }
	 }    	
	 if(eof_recv){
	   break;
	 }
  }
    fclose(file); 
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <port> <droppc>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    int s_fd_server, in_port, droppc;
    
    in_port = atoi(argv[1]);
    droppc = atoi(argv[2]);

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(in_port);

    // Create socket
    if((s_fd_server = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
        fprintf(stderr, "Error in socket creation\n");
        exit(EXIT_FAILURE);
    }

    // Bind socket to the port
    if(bind(s_fd_server, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0){
        fprintf(stderr, "Error in binding\n");
        close(s_fd_server);
        exit(EXIT_FAILURE);
    }
    // Handle incoming packets
    dg_serv(s_fd_server, droppc);

    // Close socket
    close(s_fd_server);

    return 0;
}
