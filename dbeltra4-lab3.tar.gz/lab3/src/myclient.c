#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <pthread.h>
#define MAXLINE         1450 
#define MAX_RETRANSMIT  5
#define EOF_SEQ_NUM -1

typedef struct Packet {
    int seq_number;
    int d_len;
    char data[MAXLINE];
} Packet;

void msg_log(char* packet_type, int pktsn, int basesn, int nextsn, int winsz) {
    time_t cur_time;
    char timestamp[64];
    struct timeval tv;

    gettimeofday(&tv, NULL);
    cur_time = tv.tv_sec;

    struct tm* time_info = gmtime(&cur_time);
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%dT%H:%M:%S", time_info);

    // Print timestamp and message
    int mils = tv.tv_usec / 1000;
    printf("%s.%03dZ, %s, %d, %d, %d, %d\n", timestamp, mils, packet_type, pktsn, basesn, nextsn, basesn + winsz);
}

void cli_send_data(int s_fd, struct sockaddr *pservaddr, socklen_t servlen, int mtu, int winsz, FILE *in_file, const char *out){
    // Timeout Socket Call
    struct timeval t;
    t.tv_sec = 30;
    t.tv_usec = 0;
    if(setsockopt(s_fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof(t)) < 0){
        fprintf(stderr, "Error in setsockopt()\n");
        exit(EXIT_FAILURE);
    } 
    // Calculate packets
    fseek(in_file, 0, SEEK_END);
    long f_size = ftell(in_file);
    rewind(in_file);
    int num_packets = (f_size + mtu - 1) / mtu;

    if(sendto(s_fd, out, strlen(out) + 1, 0, pservaddr, servlen) < 0){
       fprintf(stderr, "Error sending file path to server\n");
       exit(EXIT_FAILURE);
    }
    printf("File path sent to server: %s\n", out);

    Packet P[MAXLINE];
    int next_sn = 0;
    int base = 0;
    size_t read_bite;

    int retransmit[num_packets];
    memset(retransmit, 0, sizeof(retransmit));
    printf("Number of packets to send: %d\n", num_packets);
    while(base < num_packets) {
        // Send packets within window
        while((next_sn < base + winsz) && (next_sn < num_packets)) {
            Packet p;
            read_bite = fread(p.data, 1, mtu, in_file);
            p.seq_number = next_sn;
	    p.d_len = read_bite;

            // Store the packets
            P[next_sn % MAXLINE] = p;

	    printf("Sending packet %d\n", p.seq_number);

            if(sendto(s_fd, &p, sizeof(p.seq_number) + sizeof(p.d_len) + read_bite, 0, pservaddr, servlen) < 0){
                fprintf(stderr, "Error in sendto() for client...\n");
                exit(EXIT_FAILURE);
            }
	        // Logging Data Pkts
	        msg_log("DATA", p.seq_number, base, next_sn, base + winsz);
                next_sn++;
        }

        // Resend packets for which acknowledgment not received
        for(int i = base; i < next_sn; i++){
            Packet ack;
            ssize_t ack_len;
	   
            if((ack_len = recvfrom(s_fd, &ack, sizeof(Packet), 0, NULL, NULL)) < 0){
                if(errno == EAGAIN || errno == EWOULDBLOCK) {
                   fprintf(stderr, "Cannot detect server\n");
                   exit(EXIT_FAILURE);
                }else{
                   fprintf(stderr, "Error in recvfrom() for client: %s\n", strerror(errno));
                   exit(EXIT_FAILURE);
                }
            }else{ // if ack_len/else
                if(ack_len >= 0 && ack.seq_number >= base && ack.seq_number < next_sn){
                   msg_log("ACK", ack.seq_number, base, next_sn, base + winsz);              
                   base = ack.seq_number + 1;
                }else{
                    // Handle out-of-order or incorrect acknowledgments
                   fprintf(stderr, "Received incorrect acknowledgment for packet %d. Ignoring...\n", i);
                }
            }
            
            // Handle packet loss and retransmissions
            if(ack_len < 0 || ack.seq_number != i) {
               retransmit[i]++;
               if (retransmit[i] >= 3 && retransmit[i] <= MAX_RETRANSMIT) {
                   fprintf(stderr, "Packet loss detected for packet %d. Retransmitting (attempt %d)...\n", i, retransmit[i]);
                   if(sendto(s_fd, &P[i % MAXLINE], sizeof(Packet), 0, pservaddr, servlen) < 0){
                       fprintf(stderr, "Error in sendto() for client...\n");
                       exit(EXIT_FAILURE);
                    }
                }else if (retransmit[i] > MAX_RETRANSMIT) {
                   fprintf(stderr, "Reached max re-transmission limit for packet %d\n", i);
                   exit(EXIT_FAILURE);
                }
            } 
        }
        // For loop
    } // Second While Loop

    // Sending of EOF Packets----------------------------------------------------------------------------

    Packet EF;
    EF.seq_number = EOF_SEQ_NUM;
    EF.d_len = 0;
    printf("EF.d_len = %d\n", EF.d_len);
    if(sendto(s_fd, &EF, sizeof(Packet), 0, pservaddr, servlen) < 0){
        fprintf(stderr, "Error in sendto(EF) for client...\n");
        exit(EXIT_FAILURE);
    } 
    printf("Sent EOF Packet\n");
    t.tv_sec = 30;
    if(setsockopt(s_fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof(t)) < 0){
        fprintf(stderr, "Error in setsockopt()\n");
        exit(EXIT_FAILURE);
    } 
    Packet EF_ack;
    int recv_ack; 
    if((recv_ack = recvfrom(s_fd, &EF_ack, sizeof(Packet), 0, NULL, NULL) < 0)){
	if(errno == EWOULDBLOCK || errno == EAGAIN){
           fprintf(stderr, "Timeout occurred. No acknowledgment received.\n");
           exit(EXIT_FAILURE);	
	} else{
           fprintf(stderr, "Error in recvfrom() for client...\n");
           exit(EXIT_FAILURE);     
        } 
    } else{
    	   printf("Received acknowledgment for EOF packet\n");
    }
    fclose(in_file);

    if(sendto(s_fd, out, strlen(out), 0, pservaddr, servlen) < 0){
        fprintf(stderr, "Error in sendto() for client...\n");
        exit(EXIT_FAILURE);
    }
    printf("Sent output file path to server: %s\n", out);
}

int main(int arg, char *argv[]){
     if(arg != 7){
	fprintf(stderr, "Usage: %s <IP> <port> <MTU> <winz> <in_file_path> <out_file_path>\n", argv[0]);
        exit(EXIT_FAILURE);
     }
     printf("size of packet: %ld\n", sizeof(Packet));
     struct sockaddr_in client_addr;
     int s_fd_client, port_num, mtu, winsz; 
     
     const char *IP = argv[1];
     port_num = atoi(argv[2]);
     mtu = atoi(argv[3]);
     winsz = atoi(argv[4]);
     const char *in_file_s = argv[5];
     const char *out_file_s = argv[6];

     if(mtu <= (int)sizeof(Packet)){
	    fprintf(stderr, "Required minimum MTU is MAXLINE + 1\n");
        exit(EXIT_FAILURE);
     }
     
     // UDP Client Constraints
     memset(&client_addr, 0, sizeof(client_addr));
     client_addr.sin_family = AF_INET;
     client_addr.sin_port = htons(port_num);

     // Setting Client Socket
     if((s_fd_client = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
         fprintf(stderr, "Error in socket\n");
         exit(EXIT_FAILURE);
    }

    if(inet_pton(AF_INET, IP, &client_addr.sin_addr) <= 0){
       fprintf(stderr, "Error in IP address validity\n");
       exit(EXIT_FAILURE);
    } 

    FILE *in_file = fopen(in_file_s, "rb");     
    if(in_file == NULL){
       fprintf(stderr, "Error in reading file\n");
       exit(EXIT_FAILURE);
    }
    printf("Input file opened successfully: %s\n", in_file_s); 
    FILE *out_file = fopen(out_file_s, "wb");
    if(out_file == NULL){
       fprintf(stderr, "Error writing file\n");
       exit(EXIT_FAILURE);
    }
    printf("Output file opened successfully: %s\n", out_file_s);

    //Call in function
    cli_send_data(s_fd_client, (struct sockaddr *)&client_addr, sizeof(client_addr), 
                  mtu, winsz, in_file, out_file_s);
                  
    fclose(out_file);
    close(s_fd_client);
    return 0;
}
