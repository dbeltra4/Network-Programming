# README for CSE 156/L: Lab1 Simple Web Downloader

## Name: Daniel Beltran
## ID: 1802452

## myweb.c
--------------------------------------------------
The file myweb.c handles functionalites akin to wget and curl. This initial lab asks to 
create this "Simple Web Downloader" on the client side. This means as the client, the 
operations revolve around connect() and recv()/read() to retrieve information from a server
and back to the client. In order to read or receive data, we must indicate with method to use.
In order to construct the HTTP Response, the use of sprint for HEAD or GET which we write() to.
In order to tese the functionality, an example is shown below:
```
./myweb www.example.com 93.184.216.34/index.html 

or

./myweb www.example.com 93.184.216.34/index.html -h
```

The following commands execute either retrieve the document body to output.dat (without -h) 
and with the optional parameter it retrieves to the console. 
