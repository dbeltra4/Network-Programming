#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <regex.h>
#define MAXLINE         1024    /* max test line length */

// References made to the use of Google and Socket Programming Textbook
// Formatting will be similar to that of the assigned reading

void send_request(const char* host, const char* IP, int port, const char* path, int header){    
     // Socket that connects to server
     int s_fd;
     if((s_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
  	perror("socket");
	exit(EXIT_FAILURE);
     }

     // Define the TCP socket
     struct sockaddr_in server_addr;
     server_addr.sin_family = AF_INET; 
     server_addr.sin_port = htons(port);
     
     // Checks for IP Formatting
     if(inet_pton(AF_INET, IP, &server_addr.sin_addr) <= 0){
        perror("IP Formatting");
        exit(EXIT_FAILURE);
     }

     // Checks for stable connection     
     if(connect(s_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1){
        perror("Connect failed");
        exit(EXIT_FAILURE);
     }
     
     // Send HTTP responses
     char request[MAXLINE + 1]; 

     sprintf(request, 
             "%s /%s HTTP/1.1\r\nHost: %s\r\n\r\n", 
             header ? "HEAD" : "GET", path, host);
      
     if(write(s_fd, request, strlen(request)) < 0){
	perror("Write");
	exit(EXIT_FAILURE);
     }
  
     // Recieves the response data ----------------------------------------------------------
     char buff[MAXLINE + 1];
     ssize_t read_bite;
     if(!header){
	FILE *out = fopen("output.dat", "wb");
	if(out == NULL){
           perror("fopen");
	   exit(EXIT_FAILURE);
        }
     // Continues reading
     int header_found = 0;
     size_t content_len = 0;  
     char *content_length_pattern = "Content-Length: ([0-9]+)"; // captures the content length
     regex_t regex; // reg expression variable
     regmatch_t match[2];  // One for the entire match, one for the captured group

     // call on regcomp() with the patter and "Use Extended Regular Expressions"
     if(regcomp(&regex, content_length_pattern, REG_EXTENDED) != 0){
	perror("regcomp");
	exit(EXIT_FAILURE);
     }

     while((read_bite = read(s_fd, buff, MAXLINE)) > 0){
	   if(!header_found){       
              buff[read_bite] = '\0'; // NULL Terminate
	      char *end_of_hr = strstr(buff, "\r\n\r\n"); // end of the header and response, focusing on the document
              if(end_of_hr != NULL){      
		 header_found = 1; // Header found!
                 end_of_hr += 4;  // We move by 4 byte "\r\n\r\n"
	         
	         if(regexec(&regex, buff, 2, match, 0) == 0){ // ensures the buffer matches regex (pattern)
		    char content_length_str[32];
		    strncpy(content_length_str, buff + match[1].rm_so, match[1].rm_eo - match[1].rm_so); // Copies content-len
		    content_length_str[match[1].rm_eo - match[1].rm_so] = '\0'; // NULL Ternimate string
		    content_len = atoi(content_length_str); // Convert from string to integer
		 } 

		 size_t body_start = end_of_hr - buff; // The stored buff minus the header/response
		 size_t remaining_body = read_bite - body_start; 
		 fwrite(end_of_hr, 1, remaining_body, out); // Writes the document
		 if(content_len == 0){ 
		    break;
	         }
             } 
	   }else{ // header is found, write to the file 
	        fwrite(buff, 1, read_bite, out);     
                if(content_len > 0 && (size_t)ftell(out) >= content_len){ // Ensures there's data and compres with out file
		   break;
                }  
	   }
     }
     fclose(out); 
     regfree(&regex); 
    }else{
       while((read_bite = read(s_fd, buff, MAXLINE)) > 0){
	      fwrite(buff, read_bite, 1, stdout);
	      if(strstr(buff, "\r\n\r\n") != NULL){
		 break;
	      }
       }
     } 
    close(s_fd);	   
}

int main(int arg, char *argv[]){
    // Simple case for input
    if(arg <  3 || arg > 4){
       fprintf(stderr, "Usage: %s <host> <ip>[:<port>] <path> [-h]\n", argv[0]);
       exit(EXIT_FAILURE);
    }
    // Inputs for myweb.c    
    const char *host = argv[1];
    const char *iPPath = argv[2];
    
    int header_only = (arg == 4 && (strcmp(argv[3], "-h") == 0));

    // IPort is the IP and Port so we must break it down. 
    char IP[16]; 
    int port = 80;
    char path[256]; 
    
    // We parse the input, with or without the port input
    if(sscanf(iPPath, "%15[^:]:%d/%s", IP, &port, path) != 3){
       if(sscanf(iPPath, "%15[^/]/%s", IP, path) != 2){
	  fprintf(stderr, "Invalid formatting: IP or Port\n");
	  exit(EXIT_FAILURE);
       }
    }
 
    send_request(host, IP, port, path, header_only);
    
    return 0;
}
